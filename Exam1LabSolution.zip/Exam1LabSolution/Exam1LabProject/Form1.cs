﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* Solana Barton
 * ITD 1253
 * Fall 2021
 * Due 10/12/218*/

namespace Exam1LabProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox.Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnA_Click(object sender, EventArgs e)
        {
            textBox.Text = "A";
            label.Text = label.Text + "A";
        }

        private void btnB_Click(object sender, EventArgs e)
        {
            textBox.Text = "B";
            label.Text = label.Text + "B";
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            textBox.Text = "C";
            label.Text = label.Text + "C";
        }

        private void btnD_Click(object sender, EventArgs e)
        {
            textBox.Text = "D";
            label.Text = label.Text + "D";
        }

        private void btnE_Click(object sender, EventArgs e)
        {
            textBox.Text = "E";
            label.Text = label.Text + "E";
        }

        private void btnF_Click(object sender, EventArgs e)
        {
            textBox.Text = "F";
            label.Text = label.Text + "F";
        }

        private void btnG_Click(object sender, EventArgs e)
        {
            textBox.Text = "G";
            label.Text = label.Text + "G";
        }

        private void btnH_Click(object sender, EventArgs e)
        {
            textBox.Text = "H";
            label.Text = label.Text + "H";
        }

        private void btnI_Click(object sender, EventArgs e)
        {
            textBox.Text = "I";
            label.Text = label.Text + "I";
        }

        private void btnJ_Click(object sender, EventArgs e)
        {
            textBox.Text = "J";
            label.Text = label.Text + "J";
        }

        private void btnK_Click(object sender, EventArgs e)
        {
            textBox.Text = "K";
            label.Text = label.Text + "K";
        }

        private void btnL_Click(object sender, EventArgs e)
        {
            textBox.Text = "L";
            label.Text = label.Text + "L";
        }

        private void btnM_Click(object sender, EventArgs e)
        {
            textBox.Text = "M";
            label.Text = label.Text + "M";
        }

        private void btnN_Click(object sender, EventArgs e)
        {
            textBox.Text = "N";
            label.Text = label.Text + "N";
        }

        private void btnO_Click(object sender, EventArgs e)
        {
            textBox.Text = "O";
            label.Text = label.Text + "O";
        }

        private void btnP_Click(object sender, EventArgs e)
        {
            textBox.Text = "P";
            label.Text = label.Text + "P";
        }

        private void btnQ_Click(object sender, EventArgs e)
        {
            textBox.Text = "Q";
            label.Text = label.Text + "Q";
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            textBox.Text = "R";
            label.Text = label.Text + "R";
        }

        private void btnS_Click(object sender, EventArgs e)
        {
            textBox.Text = "S";
            label.Text = label.Text + "S";
        }

        private void btnT_Click(object sender, EventArgs e)
        {
            textBox.Text = "T";
            label.Text = label.Text + "T";
        }

        private void btnU_Click(object sender, EventArgs e)
        {
            textBox.Text = "U";
            label.Text = label.Text + "U";
        }

        private void btnV_Click(object sender, EventArgs e)
        {
            textBox.Text = "V";
            label.Text = label.Text + "V";
        }

        private void btnW_Click(object sender, EventArgs e)
        {
            textBox.Text = "W";
            label.Text = label.Text + "W";
        }

        private void btnX_Click(object sender, EventArgs e)
        {
            textBox.Text = "X";
            label.Text = label.Text + "X";
        }

        private void btnY_Click(object sender, EventArgs e)
        {
            textBox.Text = "Y";
            label.Text = label.Text + "Y";
        }

        private void btnZ_Click(object sender, EventArgs e)
        {
            textBox.Text = "Z";
            label.Text = label.Text + "Z";
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            textBox.Text = "0";
            label.Text = label.Text + "0";
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            textBox.Text = "1";
            label.Text = label.Text + "1";
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            textBox.Text = "2";
            label.Text = label.Text + "2";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            textBox.Text = "3";
            label.Text = label.Text + "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            textBox.Text = "4";
            label.Text = label.Text + "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            textBox.Text = "5";
            label.Text = label.Text + "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            textBox.Text = "6";
            label.Text = label.Text + "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            textBox.Text = "7";
            label.Text = label.Text + "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            textBox.Text = "8";
            label.Text = label.Text + "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            textBox.Text = "9";
            label.Text = label.Text + "9";
        }

        private void btnPeriod_Click(object sender, EventArgs e)
        {
            textBox.Text = ".";
            label.Text = label.Text + ".";
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            textBox.Text = label.Text;
        }

        private void btnBlankSpace_Click(object sender, EventArgs e)
        {
            textBox.Text = " ";
            label.Text = label.Text + " ";
        }
    }
}
