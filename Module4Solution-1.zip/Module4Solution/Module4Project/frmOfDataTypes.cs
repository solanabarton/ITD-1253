﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* Solana Barton
 * ITD 1253
 * 10/5/21*/

namespace Module4Project
{
    public partial class frmOfDataTypes : Form
    {
        private int a;
        private int b;
        private double result;

        public frmOfDataTypes()
        {
            InitializeComponent();
            a = 2;
            b = 3;

        }

        private void btnShort_Click(object sender, EventArgs e)
        {
            
                short result = (short)(a - b);
                label.Text = result.ToString();

        }

        private void btnLong_Click(object sender, EventArgs e)
        {
            long result = a % b;
            label.Text = result.ToString();
        }

        private void btnDouble_Click(object sender, EventArgs e)
        {
            double result = a / b;
            label.Text = result.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            label.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnByte_Click(object sender, EventArgs e)
        {
            short result = (byte)(a + b);
            label.Text = result.ToString();
        }

        private void btnInt_Click(object sender, EventArgs e)
        {
            int result = a / b;
            label.Text = result.ToString();
        }

        private void btnFloat_Click(object sender, EventArgs e)
        {
            float result = a % b;
            label.Text = result.ToString();
        }

        private void btnDecimal_Click(object sender, EventArgs e)
        {
            decimal result = a * b;
            label.Text = result.ToString();
        }

        private void btnPow_Click(object sender, EventArgs e)
        {
            result = Math.Pow(2, 3);
            label.Text = result.ToString();
        }

        private void btnRound_Click(object sender, EventArgs e)
        {
            result = Math.Round(2.0, 3);
            label.Text = result.ToString();
        }

        private void btnSqrt_Click(object sender, EventArgs e)
        {
            result = Math.Sqrt(2);
            label.Text = result.ToString();
        }

        private void label_Click(object sender, EventArgs e)
        {

        }
    }
}
