﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* Solana Barton
 * ITD 1253
 * Due 10/14/21 Fall 2021*/

namespace Module5ProjectIFS
{
    public partial class frmChoices : Form
    {
        private int a;
        private int b;

        public frmChoices()
        {
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            lblMessage.Text = " ";
        }

        private void lblMessage_Click(object sender, EventArgs e)
        {
            
        }

        private void textBoxLeft_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBoxCenter_TextChanged(object sender, EventArgs e)
        {
            int value = textBoxCenter;
            if (value >= -1000 && value <= 1000)
            {
                lblMessage.Text = "This value is within range.";
            }

    }
    }
