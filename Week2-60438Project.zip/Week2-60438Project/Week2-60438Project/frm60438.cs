﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* Solana Barton
    ITD 1253
    9/21/21 */


namespace Week2_60438Project
{
    public partial class frm60438 : Form
    {
        public frm60438()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtBox.Text = ""; //this is clearing the texbox of content
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtBox.Text = ""; //this is canceling the text in the text box
        }

        private void txtBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            lblEnterTextHere.Text = txtBox.Text;
        }
    }
}
