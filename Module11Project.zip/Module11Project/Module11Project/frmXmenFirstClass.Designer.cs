﻿
namespace Module11Project
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnByte = new System.Windows.Forms.Button();
            this.btnShort = new System.Windows.Forms.Button();
            this.btnInt = new System.Windows.Forms.Button();
            this.btnLong = new System.Windows.Forms.Button();
            this.btnFloat = new System.Windows.Forms.Button();
            this.btnDecimal = new System.Windows.Forms.Button();
            this.btnDouble = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblLeft = new System.Windows.Forms.Label();
            this.lblRight = new System.Windows.Forms.Label();
            this.textBoxLeft = new System.Windows.Forms.TextBox();
            this.textBoxRight = new System.Windows.Forms.TextBox();
            this.groupBoxFunctions = new System.Windows.Forms.GroupBox();
            this.btnCompute = new System.Windows.Forms.Button();
            this.radioButtonModulus = new System.Windows.Forms.RadioButton();
            this.radioButtonMultiply = new System.Windows.Forms.RadioButton();
            this.radioButtonDivide = new System.Windows.Forms.RadioButton();
            this.radioButtonSubtract = new System.Windows.Forms.RadioButton();
            this.radioButtonAdd = new System.Windows.Forms.RadioButton();
            this.lblResults = new System.Windows.Forms.Label();
            this.groupBoxFunctions.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnByte
            // 
            this.btnByte.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnByte.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnByte.Location = new System.Drawing.Point(40, 91);
            this.btnByte.Name = "btnByte";
            this.btnByte.Size = new System.Drawing.Size(188, 58);
            this.btnByte.TabIndex = 0;
            this.btnByte.Text = "Byte";
            this.btnByte.UseVisualStyleBackColor = false;
            this.btnByte.Click += new System.EventHandler(this.btnByte_Click);
            // 
            // btnShort
            // 
            this.btnShort.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnShort.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnShort.Location = new System.Drawing.Point(342, 91);
            this.btnShort.Name = "btnShort";
            this.btnShort.Size = new System.Drawing.Size(188, 58);
            this.btnShort.TabIndex = 1;
            this.btnShort.Text = "Short";
            this.btnShort.UseVisualStyleBackColor = false;
            this.btnShort.Click += new System.EventHandler(this.btnShort_Click);
            // 
            // btnInt
            // 
            this.btnInt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnInt.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnInt.Location = new System.Drawing.Point(656, 91);
            this.btnInt.Name = "btnInt";
            this.btnInt.Size = new System.Drawing.Size(188, 58);
            this.btnInt.TabIndex = 2;
            this.btnInt.Text = "Int";
            this.btnInt.UseVisualStyleBackColor = false;
            this.btnInt.Click += new System.EventHandler(this.btnInt_Click);
            // 
            // btnLong
            // 
            this.btnLong.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnLong.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnLong.Location = new System.Drawing.Point(1002, 91);
            this.btnLong.Name = "btnLong";
            this.btnLong.Size = new System.Drawing.Size(188, 58);
            this.btnLong.TabIndex = 3;
            this.btnLong.Text = "Long";
            this.btnLong.UseVisualStyleBackColor = false;
            this.btnLong.Click += new System.EventHandler(this.btnLong_Click);
            // 
            // btnFloat
            // 
            this.btnFloat.BackColor = System.Drawing.Color.Lime;
            this.btnFloat.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnFloat.Location = new System.Drawing.Point(171, 233);
            this.btnFloat.Name = "btnFloat";
            this.btnFloat.Size = new System.Drawing.Size(188, 58);
            this.btnFloat.TabIndex = 4;
            this.btnFloat.Text = "Float";
            this.btnFloat.UseVisualStyleBackColor = false;
            this.btnFloat.Click += new System.EventHandler(this.btnFloat_Click);
            // 
            // btnDecimal
            // 
            this.btnDecimal.BackColor = System.Drawing.Color.Lime;
            this.btnDecimal.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnDecimal.Location = new System.Drawing.Point(496, 233);
            this.btnDecimal.Name = "btnDecimal";
            this.btnDecimal.Size = new System.Drawing.Size(188, 58);
            this.btnDecimal.TabIndex = 5;
            this.btnDecimal.Text = "Decimal";
            this.btnDecimal.UseVisualStyleBackColor = false;
            this.btnDecimal.Click += new System.EventHandler(this.btnDecimal_Click);
            // 
            // btnDouble
            // 
            this.btnDouble.BackColor = System.Drawing.Color.Lime;
            this.btnDouble.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnDouble.Location = new System.Drawing.Point(848, 233);
            this.btnDouble.Name = "btnDouble";
            this.btnDouble.Size = new System.Drawing.Size(188, 58);
            this.btnDouble.TabIndex = 6;
            this.btnDouble.Text = "Double";
            this.btnDouble.UseVisualStyleBackColor = false;
            this.btnDouble.Click += new System.EventHandler(this.btnDouble_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.White;
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 11.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnClear.Location = new System.Drawing.Point(60, 1067);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(188, 58);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.White;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 11.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnExit.Location = new System.Drawing.Point(1455, 1067);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(188, 58);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblLeft
            // 
            this.lblLeft.AutoSize = true;
            this.lblLeft.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblLeft.Location = new System.Drawing.Point(60, 811);
            this.lblLeft.Name = "lblLeft";
            this.lblLeft.Size = new System.Drawing.Size(213, 41);
            this.lblLeft.TabIndex = 9;
            this.lblLeft.Text = "Left Operand:";
            // 
            // lblRight
            // 
            this.lblRight.AutoSize = true;
            this.lblRight.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRight.Location = new System.Drawing.Point(60, 960);
            this.lblRight.Name = "lblRight";
            this.lblRight.Size = new System.Drawing.Size(235, 41);
            this.lblRight.TabIndex = 10;
            this.lblRight.Text = "Right Operand:";
            // 
            // textBoxLeft
            // 
            this.textBoxLeft.Location = new System.Drawing.Point(417, 805);
            this.textBoxLeft.Name = "textBoxLeft";
            this.textBoxLeft.Size = new System.Drawing.Size(708, 47);
            this.textBoxLeft.TabIndex = 11;
            this.textBoxLeft.TextChanged += new System.EventHandler(this.textBoxLeft_TextChanged);
            // 
            // textBoxRight
            // 
            this.textBoxRight.Location = new System.Drawing.Point(417, 960);
            this.textBoxRight.Name = "textBoxRight";
            this.textBoxRight.Size = new System.Drawing.Size(708, 47);
            this.textBoxRight.TabIndex = 12;
            this.textBoxRight.TextChanged += new System.EventHandler(this.textBoxRight_TextChanged);
            // 
            // groupBoxFunctions
            // 
            this.groupBoxFunctions.Controls.Add(this.btnCompute);
            this.groupBoxFunctions.Controls.Add(this.radioButtonModulus);
            this.groupBoxFunctions.Controls.Add(this.radioButtonMultiply);
            this.groupBoxFunctions.Controls.Add(this.radioButtonDivide);
            this.groupBoxFunctions.Controls.Add(this.radioButtonSubtract);
            this.groupBoxFunctions.Controls.Add(this.radioButtonAdd);
            this.groupBoxFunctions.Location = new System.Drawing.Point(1205, 337);
            this.groupBoxFunctions.Name = "groupBoxFunctions";
            this.groupBoxFunctions.Size = new System.Drawing.Size(438, 537);
            this.groupBoxFunctions.TabIndex = 13;
            this.groupBoxFunctions.TabStop = false;
            this.groupBoxFunctions.Text = "Functions";
            // 
            // btnCompute
            // 
            this.btnCompute.BackColor = System.Drawing.Color.Cyan;
            this.btnCompute.Location = new System.Drawing.Point(230, 457);
            this.btnCompute.Name = "btnCompute";
            this.btnCompute.Size = new System.Drawing.Size(188, 58);
            this.btnCompute.TabIndex = 14;
            this.btnCompute.Text = "Compute";
            this.btnCompute.UseVisualStyleBackColor = false;
            // 
            // radioButtonModulus
            // 
            this.radioButtonModulus.AutoSize = true;
            this.radioButtonModulus.Location = new System.Drawing.Point(19, 386);
            this.radioButtonModulus.Name = "radioButtonModulus";
            this.radioButtonModulus.Size = new System.Drawing.Size(172, 45);
            this.radioButtonModulus.TabIndex = 4;
            this.radioButtonModulus.TabStop = true;
            this.radioButtonModulus.Text = "Modulus";
            this.radioButtonModulus.UseVisualStyleBackColor = true;
            this.radioButtonModulus.CheckedChanged += new System.EventHandler(this.radioButtonModulus_CheckedChanged);
            // 
            // radioButtonMultiply
            // 
            this.radioButtonMultiply.AutoSize = true;
            this.radioButtonMultiply.Location = new System.Drawing.Point(19, 303);
            this.radioButtonMultiply.Name = "radioButtonMultiply";
            this.radioButtonMultiply.Size = new System.Drawing.Size(171, 45);
            this.radioButtonMultiply.TabIndex = 3;
            this.radioButtonMultiply.TabStop = true;
            this.radioButtonMultiply.Text = " Multiply";
            this.radioButtonMultiply.UseVisualStyleBackColor = true;
            this.radioButtonMultiply.CheckedChanged += new System.EventHandler(this.radioButtonMultiply_CheckedChanged);
            // 
            // radioButtonDivide
            // 
            this.radioButtonDivide.AutoSize = true;
            this.radioButtonDivide.Location = new System.Drawing.Point(19, 229);
            this.radioButtonDivide.Name = "radioButtonDivide";
            this.radioButtonDivide.Size = new System.Drawing.Size(138, 45);
            this.radioButtonDivide.TabIndex = 2;
            this.radioButtonDivide.TabStop = true;
            this.radioButtonDivide.Text = "Divide";
            this.radioButtonDivide.UseVisualStyleBackColor = true;
            this.radioButtonDivide.CheckedChanged += new System.EventHandler(this.radioButtonDivide_CheckedChanged);
            // 
            // radioButtonSubtract
            // 
            this.radioButtonSubtract.AutoSize = true;
            this.radioButtonSubtract.Location = new System.Drawing.Point(19, 160);
            this.radioButtonSubtract.Name = "radioButtonSubtract";
            this.radioButtonSubtract.Size = new System.Drawing.Size(165, 45);
            this.radioButtonSubtract.TabIndex = 1;
            this.radioButtonSubtract.TabStop = true;
            this.radioButtonSubtract.Text = "Subtract";
            this.radioButtonSubtract.UseVisualStyleBackColor = true;
            this.radioButtonSubtract.CheckedChanged += new System.EventHandler(this.radioButtonSubtract_CheckedChanged);
            // 
            // radioButtonAdd
            // 
            this.radioButtonAdd.AutoSize = true;
            this.radioButtonAdd.Location = new System.Drawing.Point(19, 85);
            this.radioButtonAdd.Name = "radioButtonAdd";
            this.radioButtonAdd.Size = new System.Drawing.Size(110, 45);
            this.radioButtonAdd.TabIndex = 0;
            this.radioButtonAdd.TabStop = true;
            this.radioButtonAdd.Text = "Add";
            this.radioButtonAdd.UseVisualStyleBackColor = true;
            this.radioButtonAdd.CheckedChanged += new System.EventHandler(this.radioButtonAdd_CheckedChanged);
            // 
            // lblResults
            // 
            this.lblResults.BackColor = System.Drawing.Color.LightBlue;
            this.lblResults.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblResults.Location = new System.Drawing.Point(60, 412);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(1094, 328);
            this.lblResults.TabIndex = 5;
            this.lblResults.Text = "Click a Button";
            this.lblResults.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 41F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1671, 1149);
            this.Controls.Add(this.lblResults);
            this.Controls.Add(this.groupBoxFunctions);
            this.Controls.Add(this.textBoxRight);
            this.Controls.Add(this.textBoxLeft);
            this.Controls.Add(this.lblRight);
            this.Controls.Add(this.lblLeft);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnDouble);
            this.Controls.Add(this.btnDecimal);
            this.Controls.Add(this.btnFloat);
            this.Controls.Add(this.btnLong);
            this.Controls.Add(this.btnInt);
            this.Controls.Add(this.btnShort);
            this.Controls.Add(this.btnByte);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Classes Commence";
            this.groupBoxFunctions.ResumeLayout(false);
            this.groupBoxFunctions.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnByte;
        private System.Windows.Forms.Button btnShort;
        private System.Windows.Forms.Button btnInt;
        private System.Windows.Forms.Button btnLong;
        private System.Windows.Forms.Button btnFloat;
        private System.Windows.Forms.Button btnDecimal;
        private System.Windows.Forms.Button btnDouble;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblLeft;
        private System.Windows.Forms.Label lblRight;
        private System.Windows.Forms.TextBox textBoxLeft;
        private System.Windows.Forms.TextBox textBoxRight;
        private System.Windows.Forms.GroupBox groupBoxFunctions;
        private System.Windows.Forms.RadioButton radioButtonModulus;
        private System.Windows.Forms.RadioButton radioButtonMultiply;
        private System.Windows.Forms.RadioButton radioButtonDivide;
        private System.Windows.Forms.RadioButton radioButtonSubtract;
        private System.Windows.Forms.RadioButton radioButtonAdd;
        private System.Windows.Forms.Label lblResults;
        private System.Windows.Forms.Button btnCompute;
    }
}

