﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MathClassC
{

    class MathFunctions
    {


    }
}

namespace Module11Project
{
    public partial class Form1 : Form
    {
        private int a;
        private int b;

        public Form1()
        {
            InitializeComponent();

            

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lblResults.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnShort_Click(object sender, EventArgs e)
        {
            short result = (short)(a - b);
            lblResults.Text = result.ToString();
        }

        private void btnLong_Click(object sender, EventArgs e)
        {
            long result = a % b;
            lblResults.Text = result.ToString();
        }

        private void btnDouble_Click(object sender, EventArgs e)
        {
            double result = a / b;
            lblResults.Text = result.ToString();
        }

        private void btnByte_Click(object sender, EventArgs e)
        {
            short result = (byte)(a + b);
            lblResults.Text = result.ToString();
        }

        private void btnInt_Click(object sender, EventArgs e)
        {
            int result = a / b;
            lblResults.Text = result.ToString();
        }

        private void btnFloat_Click(object sender, EventArgs e)
        {
            float result = a % b;
            lblResults.Text = result.ToString();
        }

        private void btnDecimal_Click(object sender, EventArgs e)
        {
            decimal result = a * b;
            lblResults.Text = result.ToString();
        }

        private void radioButtonAdd_CheckedChanged(object sender, EventArgs e)
        {
            int result = a + b;
            lblResults.Text = result.ToString();
        }

        private void radioButtonSubtract_CheckedChanged(object sender, EventArgs e)
        {
            int result = a - b;
            lblResults.Text = result.ToString();
        }

        private void radioButtonDivide_CheckedChanged(object sender, EventArgs e)
        {
            int result = a / b;
            lblResults.Text = result.ToString();
        }

        private void radioButtonMultiply_CheckedChanged(object sender, EventArgs e)
        {
            int result = a * b;
            lblResults.Text = result.ToString();
        }

        private void radioButtonModulus_CheckedChanged(object sender, EventArgs e)
        {
            int result = a % b;
            lblResults.Text = result.ToString();
        }

        private void textBoxLeft_TextChanged(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBoxLeft.Text))
            {
                lblResults.Text = "The left field is empty";
            }
        }

        private void textBoxRight_TextChanged(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBoxLeft.Text))
            {
                lblResults.Text = "The field is empty";
            }
        }
    }
}
