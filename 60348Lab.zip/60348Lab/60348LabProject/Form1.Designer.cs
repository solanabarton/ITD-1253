﻿
namespace _60348LabProject
{
    partial class frmBarton
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBlue = new System.Windows.Forms.Button();
            this.btnRed = new System.Windows.Forms.Button();
            this.btnPurple = new System.Windows.Forms.Button();
            this.btnThistle = new System.Windows.Forms.Button();
            this.btnOrange = new System.Windows.Forms.Button();
            this.btnFuchsia = new System.Windows.Forms.Button();
            this.btnPink = new System.Windows.Forms.Button();
            this.btnGold = new System.Windows.Forms.Button();
            this.digit1 = new System.Windows.Forms.Button();
            this.digit2 = new System.Windows.Forms.Button();
            this.digit3 = new System.Windows.Forms.Button();
            this.digit4 = new System.Windows.Forms.Button();
            this.digit5 = new System.Windows.Forms.Button();
            this.digit6 = new System.Windows.Forms.Button();
            this.digit7 = new System.Windows.Forms.Button();
            this.digit8 = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.digit9 = new System.Windows.Forms.Button();
            this.TheDominator = new System.Windows.Forms.Label();
            this.btnLime = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBlue
            // 
            this.btnBlue.BackColor = System.Drawing.Color.Blue;
            this.btnBlue.Location = new System.Drawing.Point(12, 44);
            this.btnBlue.Name = "btnBlue";
            this.btnBlue.Size = new System.Drawing.Size(188, 58);
            this.btnBlue.TabIndex = 1;
            this.btnBlue.UseVisualStyleBackColor = false;
            this.btnBlue.Click += new System.EventHandler(this.btnBlue_Click);
            // 
            // btnRed
            // 
            this.btnRed.BackColor = System.Drawing.Color.Red;
            this.btnRed.Location = new System.Drawing.Point(303, 44);
            this.btnRed.Name = "btnRed";
            this.btnRed.Size = new System.Drawing.Size(188, 58);
            this.btnRed.TabIndex = 2;
            this.btnRed.UseVisualStyleBackColor = false;
            this.btnRed.Click += new System.EventHandler(this.btnRed_Click);
            // 
            // btnPurple
            // 
            this.btnPurple.BackColor = System.Drawing.Color.Purple;
            this.btnPurple.Location = new System.Drawing.Point(600, 44);
            this.btnPurple.Name = "btnPurple";
            this.btnPurple.Size = new System.Drawing.Size(188, 58);
            this.btnPurple.TabIndex = 3;
            this.btnPurple.UseVisualStyleBackColor = false;
            this.btnPurple.Click += new System.EventHandler(this.btnPurple_Click);
            // 
            // btnThistle
            // 
            this.btnThistle.BackColor = System.Drawing.Color.Thistle;
            this.btnThistle.Location = new System.Drawing.Point(12, 202);
            this.btnThistle.Name = "btnThistle";
            this.btnThistle.Size = new System.Drawing.Size(188, 58);
            this.btnThistle.TabIndex = 4;
            this.btnThistle.UseVisualStyleBackColor = false;
            this.btnThistle.Click += new System.EventHandler(this.btnThistle_Click);
            // 
            // btnOrange
            // 
            this.btnOrange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnOrange.Location = new System.Drawing.Point(303, 202);
            this.btnOrange.Name = "btnOrange";
            this.btnOrange.Size = new System.Drawing.Size(188, 58);
            this.btnOrange.TabIndex = 5;
            this.btnOrange.UseVisualStyleBackColor = false;
            this.btnOrange.Click += new System.EventHandler(this.btnOrange_Click);
            // 
            // btnFuchsia
            // 
            this.btnFuchsia.BackColor = System.Drawing.Color.Fuchsia;
            this.btnFuchsia.Location = new System.Drawing.Point(600, 202);
            this.btnFuchsia.Name = "btnFuchsia";
            this.btnFuchsia.Size = new System.Drawing.Size(188, 58);
            this.btnFuchsia.TabIndex = 6;
            this.btnFuchsia.UseVisualStyleBackColor = false;
            this.btnFuchsia.Click += new System.EventHandler(this.btnFuchsia_Click);
            // 
            // btnPink
            // 
            this.btnPink.BackColor = System.Drawing.Color.Pink;
            this.btnPink.Location = new System.Drawing.Point(20, 363);
            this.btnPink.Name = "btnPink";
            this.btnPink.Size = new System.Drawing.Size(188, 58);
            this.btnPink.TabIndex = 7;
            this.btnPink.UseVisualStyleBackColor = false;
            this.btnPink.Click += new System.EventHandler(this.btnPink_Click);
            // 
            // btnGold
            // 
            this.btnGold.BackColor = System.Drawing.Color.Gold;
            this.btnGold.Location = new System.Drawing.Point(303, 363);
            this.btnGold.Name = "btnGold";
            this.btnGold.Size = new System.Drawing.Size(188, 58);
            this.btnGold.TabIndex = 8;
            this.btnGold.UseVisualStyleBackColor = false;
            this.btnGold.Click += new System.EventHandler(this.btnGold_Click);
            // 
            // digit1
            // 
            this.digit1.BackColor = System.Drawing.Color.White;
            this.digit1.Location = new System.Drawing.Point(16, 1101);
            this.digit1.Name = "digit1";
            this.digit1.Size = new System.Drawing.Size(188, 58);
            this.digit1.TabIndex = 10;
            this.digit1.Text = "1";
            this.digit1.UseVisualStyleBackColor = false;
            this.digit1.Click += new System.EventHandler(this.digit1_Click);
            // 
            // digit2
            // 
            this.digit2.BackColor = System.Drawing.Color.White;
            this.digit2.Location = new System.Drawing.Point(303, 1101);
            this.digit2.Name = "digit2";
            this.digit2.Size = new System.Drawing.Size(188, 58);
            this.digit2.TabIndex = 11;
            this.digit2.Text = "2";
            this.digit2.UseVisualStyleBackColor = false;
            this.digit2.Click += new System.EventHandler(this.digit2_Click);
            // 
            // digit3
            // 
            this.digit3.BackColor = System.Drawing.Color.White;
            this.digit3.Location = new System.Drawing.Point(600, 1101);
            this.digit3.Name = "digit3";
            this.digit3.Size = new System.Drawing.Size(188, 58);
            this.digit3.TabIndex = 12;
            this.digit3.Text = "3";
            this.digit3.UseVisualStyleBackColor = false;
            this.digit3.Click += new System.EventHandler(this.digit3_Click);
            // 
            // digit4
            // 
            this.digit4.BackColor = System.Drawing.Color.White;
            this.digit4.Location = new System.Drawing.Point(32, 1266);
            this.digit4.Name = "digit4";
            this.digit4.Size = new System.Drawing.Size(188, 58);
            this.digit4.TabIndex = 13;
            this.digit4.Text = "4";
            this.digit4.UseVisualStyleBackColor = false;
            this.digit4.Click += new System.EventHandler(this.digit4_Click);
            // 
            // digit5
            // 
            this.digit5.BackColor = System.Drawing.Color.White;
            this.digit5.Location = new System.Drawing.Point(303, 1266);
            this.digit5.Name = "digit5";
            this.digit5.Size = new System.Drawing.Size(188, 58);
            this.digit5.TabIndex = 14;
            this.digit5.Text = "5";
            this.digit5.UseVisualStyleBackColor = false;
            this.digit5.Click += new System.EventHandler(this.digit5_Click);
            // 
            // digit6
            // 
            this.digit6.BackColor = System.Drawing.Color.White;
            this.digit6.Location = new System.Drawing.Point(600, 1266);
            this.digit6.Name = "digit6";
            this.digit6.Size = new System.Drawing.Size(188, 58);
            this.digit6.TabIndex = 15;
            this.digit6.Text = "6";
            this.digit6.UseVisualStyleBackColor = false;
            this.digit6.Click += new System.EventHandler(this.digit6_Click);
            // 
            // digit7
            // 
            this.digit7.BackColor = System.Drawing.Color.White;
            this.digit7.Location = new System.Drawing.Point(32, 1422);
            this.digit7.Name = "digit7";
            this.digit7.Size = new System.Drawing.Size(188, 58);
            this.digit7.TabIndex = 16;
            this.digit7.Text = "7";
            this.digit7.UseVisualStyleBackColor = false;
            this.digit7.Click += new System.EventHandler(this.digit7_Click);
            // 
            // digit8
            // 
            this.digit8.BackColor = System.Drawing.Color.White;
            this.digit8.Location = new System.Drawing.Point(303, 1422);
            this.digit8.Name = "digit8";
            this.digit8.Size = new System.Drawing.Size(188, 58);
            this.digit8.TabIndex = 17;
            this.digit8.Text = "8";
            this.digit8.UseVisualStyleBackColor = false;
            this.digit8.Click += new System.EventHandler(this.digit8_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.White;
            this.btnClear.Location = new System.Drawing.Point(143, 1533);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(188, 58);
            this.btnClear.TabIndex = 19;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(448, 1533);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(188, 58);
            this.btnExit.TabIndex = 20;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // digit9
            // 
            this.digit9.BackColor = System.Drawing.Color.White;
            this.digit9.Location = new System.Drawing.Point(600, 1422);
            this.digit9.Name = "digit9";
            this.digit9.Size = new System.Drawing.Size(188, 58);
            this.digit9.TabIndex = 18;
            this.digit9.Text = "9";
            this.digit9.UseVisualStyleBackColor = false;
            this.digit9.Click += new System.EventHandler(this.digit9_Click);
            // 
            // TheDominator
            // 
            this.TheDominator.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.TheDominator.Font = new System.Drawing.Font("Times New Roman", 150F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TheDominator.Location = new System.Drawing.Point(12, 476);
            this.TheDominator.Name = "TheDominator";
            this.TheDominator.Size = new System.Drawing.Size(776, 548);
            this.TheDominator.TabIndex = 0;
            this.TheDominator.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLime
            // 
            this.btnLime.BackColor = System.Drawing.Color.Lime;
            this.btnLime.Location = new System.Drawing.Point(600, 363);
            this.btnLime.Name = "btnLime";
            this.btnLime.Size = new System.Drawing.Size(188, 58);
            this.btnLime.TabIndex = 9;
            this.btnLime.UseVisualStyleBackColor = false;
            this.btnLime.Click += new System.EventHandler(this.btnLime_Click);
            // 
            // frmBarton
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 41F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(800, 1612);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.digit9);
            this.Controls.Add(this.digit8);
            this.Controls.Add(this.digit7);
            this.Controls.Add(this.digit6);
            this.Controls.Add(this.digit5);
            this.Controls.Add(this.digit4);
            this.Controls.Add(this.digit3);
            this.Controls.Add(this.digit2);
            this.Controls.Add(this.digit1);
            this.Controls.Add(this.btnLime);
            this.Controls.Add(this.btnGold);
            this.Controls.Add(this.btnPink);
            this.Controls.Add(this.btnFuchsia);
            this.Controls.Add(this.btnOrange);
            this.Controls.Add(this.btnThistle);
            this.Controls.Add(this.btnPurple);
            this.Controls.Add(this.btnRed);
            this.Controls.Add(this.btnBlue);
            this.Controls.Add(this.TheDominator);
            this.Name = "frmBarton";
            this.Text = "Section 60348 - Programming Lab";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnBlue;
        private System.Windows.Forms.Button btnRed;
        private System.Windows.Forms.Button btnPurple;
        private System.Windows.Forms.Button btnThistle;
        private System.Windows.Forms.Button btnOrange;
        private System.Windows.Forms.Button btnFuchsia;
        private System.Windows.Forms.Button btnPink;
        private System.Windows.Forms.Button btnGold;
        private System.Windows.Forms.Button digit1;
        private System.Windows.Forms.Button digit2;
        private System.Windows.Forms.Button digit3;
        private System.Windows.Forms.Button digit4;
        private System.Windows.Forms.Button digit5;
        private System.Windows.Forms.Button digit6;
        private System.Windows.Forms.Button digit7;
        private System.Windows.Forms.Button digit8;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button digit9;
        private System.Windows.Forms.Label TheDominator;
        private System.Windows.Forms.Button btnLime;
    }
}

