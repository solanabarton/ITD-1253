﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* Solana Barton
  ITD 1253
10/5/21 */

namespace _60348LabProject
{
    public partial class frmBarton : Form
    {
        public frmBarton()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            TheDominator.Text = "";
            TheDominator.BackColor = System.Drawing.Color.LightGoldenrodYellow;
        }

        private void digit1_Click(object sender, EventArgs e)
        {
            TheDominator.Text = "1";
        }

        private void btnBlue_Click(object sender, EventArgs e)
        {
            TheDominator.BackColor = System.Drawing.Color.Blue; //This is selecting the color Blue
        }

        private void digit2_Click(object sender, EventArgs e)
        {
            TheDominator.Text = "2";
        }

        private void digit3_Click(object sender, EventArgs e)
        {
            TheDominator.Text = "3";
        }

        private void digit4_Click(object sender, EventArgs e)
        {
            TheDominator.Text = "4";
        }

        private void digit5_Click(object sender, EventArgs e)
        {
            TheDominator.Text = "5";
        }

        private void digit6_Click(object sender, EventArgs e)
        {
            TheDominator.Text = "6";
        }

        private void digit7_Click(object sender, EventArgs e)
        {
            TheDominator.Text = "7";
        }

        private void digit8_Click(object sender, EventArgs e)
        {
            TheDominator.Text = "8";
        }

        private void digit9_Click(object sender, EventArgs e)
        {
            TheDominator.Text = "9";
        }

        private void btnRed_Click(object sender, EventArgs e)
        {
            TheDominator.BackColor = System.Drawing.Color.Red;  //This is selecting the color red
        }

        private void btnPurple_Click(object sender, EventArgs e)
        {
            TheDominator.BackColor = System.Drawing.Color.Purple;  //This is selecting the color purple
        }

        private void btnThistle_Click(object sender, EventArgs e)
        {
            TheDominator.BackColor = System.Drawing.Color.Thistle;  //This is selecting the color thistle
        }

        private void btnOrange_Click(object sender, EventArgs e)
        {
            TheDominator.BackColor = System.Drawing.Color.Orange;  //This is selecting the color orange
        }

        private void btnFuchsia_Click(object sender, EventArgs e)
        {
            TheDominator.BackColor = System.Drawing.Color.Fuchsia;  //This is selecting the color fuchsia
        }

        private void btnPink_Click(object sender, EventArgs e)
        {
            TheDominator.BackColor = System.Drawing.Color.Pink;  //This is selecting the color pink
        }

        private void btnGold_Click(object sender, EventArgs e)
        {
            TheDominator.BackColor = System.Drawing.Color.Gold;  //This is selecting the color gold
        }

        private void btnLime_Click(object sender, EventArgs e)
        {
            TheDominator.BackColor = System.Drawing.Color.Lime;  //This is selecting the color lime
        }
    }
}
