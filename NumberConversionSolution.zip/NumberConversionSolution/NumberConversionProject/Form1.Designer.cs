﻿
namespace NumberConversionProject
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxBase = new System.Windows.Forms.TextBox();
            this.textBoxConvertFrom = new System.Windows.Forms.TextBox();
            this.lblOutput = new System.Windows.Forms.Label();
            this.lblConvert = new System.Windows.Forms.Label();
            this.lblBase = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnProcess = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnHex = new System.Windows.Forms.Button();
            this.btnBinary = new System.Windows.Forms.Button();
            this.btnOctal = new System.Windows.Forms.Button();
            this.btnBase6 = new System.Windows.Forms.Button();
            this.btnBase9 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxBase
            // 
            this.textBoxBase.BackColor = System.Drawing.Color.OldLace;
            this.textBoxBase.Location = new System.Drawing.Point(618, 131);
            this.textBoxBase.Name = "textBoxBase";
            this.textBoxBase.Size = new System.Drawing.Size(250, 47);
            this.textBoxBase.TabIndex = 0;
            // 
            // textBoxConvertFrom
            // 
            this.textBoxConvertFrom.BackColor = System.Drawing.Color.OldLace;
            this.textBoxConvertFrom.Location = new System.Drawing.Point(568, 28);
            this.textBoxConvertFrom.Name = "textBoxConvertFrom";
            this.textBoxConvertFrom.Size = new System.Drawing.Size(300, 47);
            this.textBoxConvertFrom.TabIndex = 1;
            // 
            // lblOutput
            // 
            this.lblOutput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblOutput.Location = new System.Drawing.Point(368, 253);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(500, 47);
            this.lblOutput.TabIndex = 2;
            this.lblOutput.Text = " ";
            this.lblOutput.Click += new System.EventHandler(this.lblOutput_Click);
            // 
            // lblConvert
            // 
            this.lblConvert.AutoSize = true;
            this.lblConvert.BackColor = System.Drawing.Color.LemonChiffon;
            this.lblConvert.Location = new System.Drawing.Point(157, 28);
            this.lblConvert.Name = "lblConvert";
            this.lblConvert.Size = new System.Drawing.Size(346, 41);
            this.lblConvert.TabIndex = 3;
            this.lblConvert.Text = "Input Integer to Convert:";
            // 
            // lblBase
            // 
            this.lblBase.AutoSize = true;
            this.lblBase.BackColor = System.Drawing.Color.LemonChiffon;
            this.lblBase.Location = new System.Drawing.Point(157, 137);
            this.lblBase.Name = "lblBase";
            this.lblBase.Size = new System.Drawing.Size(185, 41);
            this.lblBase.TabIndex = 4;
            this.lblBase.Text = "Enter a Base:";
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.BackColor = System.Drawing.Color.LemonChiffon;
            this.lblMessage.Location = new System.Drawing.Point(157, 253);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(143, 41);
            this.lblMessage.TabIndex = 5;
            this.lblMessage.Text = "Message:";
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Gold;
            this.btnClear.Location = new System.Drawing.Point(157, 817);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(188, 58);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            // 
            // btnProcess
            // 
            this.btnProcess.BackColor = System.Drawing.Color.Yellow;
            this.btnProcess.Location = new System.Drawing.Point(428, 817);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(188, 58);
            this.btnProcess.TabIndex = 7;
            this.btnProcess.Text = "Process";
            this.btnProcess.UseVisualStyleBackColor = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Gold;
            this.btnExit.Location = new System.Drawing.Point(680, 817);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(188, 58);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnHex
            // 
            this.btnHex.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnHex.Location = new System.Drawing.Point(157, 458);
            this.btnHex.Name = "btnHex";
            this.btnHex.Size = new System.Drawing.Size(188, 58);
            this.btnHex.TabIndex = 9;
            this.btnHex.Text = "Hex";
            this.btnHex.UseVisualStyleBackColor = false;
            this.btnHex.Click += new System.EventHandler(this.btnHex_Click);
            // 
            // btnBinary
            // 
            this.btnBinary.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnBinary.Location = new System.Drawing.Point(428, 458);
            this.btnBinary.Name = "btnBinary";
            this.btnBinary.Size = new System.Drawing.Size(188, 58);
            this.btnBinary.TabIndex = 10;
            this.btnBinary.Text = "Binary";
            this.btnBinary.UseVisualStyleBackColor = false;
            this.btnBinary.Click += new System.EventHandler(this.btnBinary_Click);
            // 
            // btnOctal
            // 
            this.btnOctal.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnOctal.Location = new System.Drawing.Point(680, 458);
            this.btnOctal.Name = "btnOctal";
            this.btnOctal.Size = new System.Drawing.Size(188, 58);
            this.btnOctal.TabIndex = 11;
            this.btnOctal.Text = "Octal";
            this.btnOctal.UseVisualStyleBackColor = false;
            this.btnOctal.Click += new System.EventHandler(this.btnOctal_Click);
            // 
            // btnBase6
            // 
            this.btnBase6.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnBase6.Location = new System.Drawing.Point(290, 652);
            this.btnBase6.Name = "btnBase6";
            this.btnBase6.Size = new System.Drawing.Size(188, 58);
            this.btnBase6.TabIndex = 12;
            this.btnBase6.Text = "Base 6";
            this.btnBase6.UseVisualStyleBackColor = false;
            this.btnBase6.Click += new System.EventHandler(this.btnBase6_Click);
            // 
            // btnBase9
            // 
            this.btnBase9.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnBase9.Location = new System.Drawing.Point(618, 652);
            this.btnBase9.Name = "btnBase9";
            this.btnBase9.Size = new System.Drawing.Size(188, 58);
            this.btnBase9.TabIndex = 13;
            this.btnBase9.Text = "Base 9";
            this.btnBase9.UseVisualStyleBackColor = false;
            this.btnBase9.Click += new System.EventHandler(this.Base_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 41F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Khaki;
            this.ClientSize = new System.Drawing.Size(1076, 1010);
            this.Controls.Add(this.btnBase9);
            this.Controls.Add(this.btnBase6);
            this.Controls.Add(this.btnOctal);
            this.Controls.Add(this.btnBinary);
            this.Controls.Add(this.btnHex);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnProcess);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.lblBase);
            this.Controls.Add(this.lblConvert);
            this.Controls.Add(this.lblOutput);
            this.Controls.Add(this.textBoxConvertFrom);
            this.Controls.Add(this.textBoxBase);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxBase;
        private System.Windows.Forms.TextBox textBoxConvertFrom;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.Label lblConvert;
        private System.Windows.Forms.Label lblBase;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnProcess;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnHex;
        private System.Windows.Forms.Button btnBinary;
        private System.Windows.Forms.Button btnOctal;
        private System.Windows.Forms.Button btnBase6;
        private System.Windows.Forms.Button btnBase9;
    }
}

