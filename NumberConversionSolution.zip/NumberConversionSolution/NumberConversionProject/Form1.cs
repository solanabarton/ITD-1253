﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NumberConversionProject
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

            var lblOutput = "";
            var characters = "0123456789ABCDEF";

        }

        public void BaseConvert (string I, string B, int H)
        {
            string lblOutput = "";
        }


        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnBase6_Click(object sender, EventArgs e)
        {
            string textBoxBase = "2";
            BaseConvert(textBoxConvertFrom.Text, textBoxBase, 0);
        }

        private void btnHex_Click(object sender, EventArgs e)
        {
            string textBoxBase = "2";
            BaseConvert(textBoxConvertFrom.Text, textBoxBase, 0);
        }

        private void btnBinary_Click(object sender, EventArgs e)
        {
            string textBoxBase = "2";
            BaseConvert(textBoxConvertFrom.Text, textBoxBase, 0);
        }

        private void btnOctal_Click(object sender, EventArgs e)
        {
            
        }

        private void Base_Click(object sender, EventArgs e)
        {
            string textBoxBase = "9";
            BaseConvert(textBoxConvertFrom.Text, textBoxBase, 0);
        }

        private void lblOutput_Click(object sender, EventArgs e)
        {

        }
    }
}
