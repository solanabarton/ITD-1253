﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Module9atinLayigPayProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

     
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = "";
            textBoxMessage.Text = "";
        }

        private bool IsMessageValid(string message)
        {
            bool isValid = false;
            if (message.Any(Char.IsLetter))
            {
                isValid = true;
            }
            return isValid;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            string regularmessage = textBoxMessage.Text;
            string pigLatinMessage = "";
            string firstLetter = "";
            string restOfWord = "";


            if (IsMessageValid(regularmessage))
            {
                foreach (string word in regularmessage.Split())
                {

                    //look and see if word has letter
                    if (word.All(Char.IsLetter))
                    {
                        firstLetter = word.Substring(0, 1);
                        restOfWord = word.Substring(1, word.Length - 1);
                        pigLatinMessage = pigLatinMessage + restOfWord + firstLetter + "ay ";
                    }
                    else
                    {
                        pigLatinMessage = pigLatinMessage + word + " ";
                    }
                }

            }
            else
            {
                pigLatinMessage = "Please only enter words.";
            }

            
            
            lblDisplay.Text = pigLatinMessage.ToString();
        }

      
    }
}
