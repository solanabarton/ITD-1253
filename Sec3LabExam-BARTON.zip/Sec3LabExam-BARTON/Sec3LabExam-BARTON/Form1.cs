﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sec3LabExam_BARTON
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string key = "npehcatimglxwvfujzkobydqrs";

        string output = "";

        int encryptionamount = 0;
        int decryptionamount = 0;


        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBoxPhrase_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            textBoxPhrase.Text = " ";
            textBoxConverted.Text = " ";
        }

        static string Encrypt(string input, string key)
        {
            char[] letters = new char[input.Length];

            for (int i = 0; i < input.Length; i++)
            {
                if(char.IsWhiteSpace(input[i]))
                {
                    letters[i] = input[i];
                }
                    else if(char.IsDigit(input[i]))
                {
                    letters[i] = input[i];
                }

                else if (char.IsPunctuation(input[i]))
                {
                    letters[i] = input[i];
                }
                else if (char.IsSymbol(input[i]))
                {
                    letters[i] = input[i];
                }
                else
                {
                    int a = char.ToLower(input[i]) - 97;
                    letters[i] = key[a];
                }
            }

            return new string(letters);
        }

        static string Decrypt(string input, string key)
        {
            char[] letters = new char[input.Length];

            for (int i = 0; i < input.Length; i++)
            {
                if (char.IsWhiteSpace(input[i]))
                {
                    letters[i] = input[i];
                }
                else if (char.IsDigit(input[i]))
                {
                    letters[i] = input[i];
                }

                else if (char.IsPunctuation(input[i]))
                {
                    letters[i] = input[i];
                }
                else if (char.IsSymbol(input[i]))
                {
                    letters[i] = input[i];
                }
                else
                {
                    int a = key.IndexOf(char.ToLower(input[i])) + 97;
                    letters[i] = (char)a;
                }
            }

            return new string(letters);
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            string inputVariable = Exceptions(textBoxPhrase.Text);
            if (radioButtonCipherText.Checked == true)
            {
                encryptionamount++;
                output = Encrypt(inputVariable, key);
                textBoxConverted.Text = output;
            }

            if (radioButtonPlainText.Checked == true)
            {
                decryptionamount++;
                output = Decrypt(inputVariable, key);
                textBoxConverted.Text = output;
            }

        }

        public string Exceptions(string variableB)
        {
            string validatedString = "";
            try
            {
                if (string.IsNullOrEmpty(variableB))

                {
                    textBoxConverted.Text = "Please enter a phrase";
                }
                else
                {
                    validatedString = variableB;
                }
            }
            catch (OverflowException)
            {
                textBoxConverted.Text = "Your String is Too Long";
            }
            catch (FormatException)
            {
                textBoxConverted.Text = "This Format is Not Accepted";
            }
            return validatedString;
        }
    }
}
