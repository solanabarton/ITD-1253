﻿
namespace Sec3LabExam_BARTON
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPhrase = new System.Windows.Forms.Label();
            this.textBoxPhrase = new System.Windows.Forms.TextBox();
            this.radioButtonPlainText = new System.Windows.Forms.RadioButton();
            this.radioButtonCipherText = new System.Windows.Forms.RadioButton();
            this.textBoxConverted = new System.Windows.Forms.TextBox();
            this.lblConverted = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnConvert = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPhrase
            // 
            this.lblPhrase.AutoSize = true;
            this.lblPhrase.Font = new System.Drawing.Font("Segoe UI", 14.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPhrase.Location = new System.Drawing.Point(12, 31);
            this.lblPhrase.Name = "lblPhrase";
            this.lblPhrase.Size = new System.Drawing.Size(340, 62);
            this.lblPhrase.TabIndex = 0;
            this.lblPhrase.Text = "Enter a Phrase";
            // 
            // textBoxPhrase
            // 
            this.textBoxPhrase.Font = new System.Drawing.Font("Segoe UI", 14.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBoxPhrase.Location = new System.Drawing.Point(461, 31);
            this.textBoxPhrase.Name = "textBoxPhrase";
            this.textBoxPhrase.Size = new System.Drawing.Size(939, 70);
            this.textBoxPhrase.TabIndex = 1;
            this.textBoxPhrase.TextChanged += new System.EventHandler(this.textBoxPhrase_TextChanged);
            // 
            // radioButtonPlainText
            // 
            this.radioButtonPlainText.AutoSize = true;
            this.radioButtonPlainText.Font = new System.Drawing.Font("Segoe UI", 14.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.radioButtonPlainText.Location = new System.Drawing.Point(863, 66);
            this.radioButtonPlainText.Name = "radioButtonPlainText";
            this.radioButtonPlainText.Size = new System.Drawing.Size(525, 66);
            this.radioButtonPlainText.TabIndex = 2;
            this.radioButtonPlainText.TabStop = true;
            this.radioButtonPlainText.Text = "Convert to Plain Text";
            this.radioButtonPlainText.UseVisualStyleBackColor = true;
            // 
            // radioButtonCipherText
            // 
            this.radioButtonCipherText.AutoSize = true;
            this.radioButtonCipherText.Font = new System.Drawing.Font("Segoe UI", 14.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.radioButtonCipherText.Location = new System.Drawing.Point(6, 66);
            this.radioButtonCipherText.Name = "radioButtonCipherText";
            this.radioButtonCipherText.Size = new System.Drawing.Size(560, 66);
            this.radioButtonCipherText.TabIndex = 3;
            this.radioButtonCipherText.TabStop = true;
            this.radioButtonCipherText.Text = "Convert to Cipher Text";
            this.radioButtonCipherText.UseVisualStyleBackColor = true;
            // 
            // textBoxConverted
            // 
            this.textBoxConverted.Font = new System.Drawing.Font("Segoe UI", 14.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBoxConverted.Location = new System.Drawing.Point(461, 372);
            this.textBoxConverted.Name = "textBoxConverted";
            this.textBoxConverted.Size = new System.Drawing.Size(939, 70);
            this.textBoxConverted.TabIndex = 4;
            // 
            // lblConverted
            // 
            this.lblConverted.AutoSize = true;
            this.lblConverted.Font = new System.Drawing.Font("Segoe UI", 14.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblConverted.Location = new System.Drawing.Point(12, 372);
            this.lblConverted.Name = "lblConverted";
            this.lblConverted.Size = new System.Drawing.Size(415, 62);
            this.lblConverted.TabIndex = 5;
            this.lblConverted.Text = "Converted Phrase";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.White;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 14.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnExit.Location = new System.Drawing.Point(1167, 651);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(233, 70);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnConvert
            // 
            this.btnConvert.BackColor = System.Drawing.Color.White;
            this.btnConvert.Font = new System.Drawing.Font("Segoe UI", 14.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnConvert.Location = new System.Drawing.Point(565, 651);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(233, 70);
            this.btnConvert.TabIndex = 7;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = false;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.White;
            this.btnReset.Font = new System.Drawing.Font("Segoe UI", 14.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnReset.Location = new System.Drawing.Point(12, 651);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(233, 70);
            this.btnReset.TabIndex = 8;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonCipherText);
            this.groupBox1.Controls.Add(this.radioButtonPlainText);
            this.groupBox1.Location = new System.Drawing.Point(12, 123);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1388, 166);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 41F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1412, 858);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblConverted);
            this.Controls.Add(this.textBoxConverted);
            this.Controls.Add(this.textBoxPhrase);
            this.Controls.Add(this.lblPhrase);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPhrase;
        private System.Windows.Forms.TextBox textBoxPhrase;
        private System.Windows.Forms.RadioButton radioButtonPlainText;
        private System.Windows.Forms.RadioButton radioButtonCipherText;
        private System.Windows.Forms.TextBox textBoxConverted;
        private System.Windows.Forms.Label lblConverted;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

